package MobilidadeUrbanaAV;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class MainMobilidadeUrbana {
    static Scanner sc = new Scanner(System.in);// SCANNER
    public static void main(String[] args) {
        List <Transporte> transportes = new ArrayList<>(); // CRIANDO UMA LISTA para permitir que o usuário cadastre um objeto de cada classe obrigatória

        private String nome;
        private int velocidadeMax;
        private int autonomia;
        private String tipoDeCombustivel;
    }
//SO  SEI FAZER A LISTA NORMAL SEM ADD OBJETOS, PERDAO NA RECUPERACAO EU APRENDO ISSO /;
}
